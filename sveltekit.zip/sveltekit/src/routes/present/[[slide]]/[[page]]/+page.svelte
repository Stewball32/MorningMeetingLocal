<script lang="ts">
	import type { PageData } from './$types';
	import { pb, updateDaily } from '$lib/pb';
	import type { Student, StudentDaily, Teacher, TeacherDaily } from '$lib/pb/types';
	import { onDestroy, onMount } from 'svelte';
	import { page } from '$app/state';
	import { pushState } from '$app/navigation';
	import type { RecordSubscription } from 'pocketbase';
	import { updateSound } from '$lib/sounds';
	import Attendance from '$lib/slides/attendance/+slide.svelte';
	import { makeSearchParams } from '$lib';

	let { data }: { data: PageData } = $props();

	const todayISOString = data.todayISOString;
	let students: Student[] = $state(data.students);
	let teachers: Teacher[] = $state(data.teachers);
	let studentDailyMap: Map<string, StudentDaily> = $state(data.studentDailyMap);
	let teacherDailyMap: Map<string, TeacherDaily> = $state(data.teacherDailyMap);
	// let currentPerson: Student | Teacher | undefined = $state(undefined);

	let activeStudents: Student[] = $derived(
		students.some((student) => studentDailyMap.get(student.id)?.here === 'present')
			? students.filter((student) => studentDailyMap.get(student.id)?.here === 'present')
			: students.filter((student) => studentDailyMap.get(student.id)?.here !== 'absent')
	);
	let activeTeachers: Teacher[] = $derived(
		teachers.some((teacher) => teacherDailyMap.get(teacher.id)?.here === 'present')
			? teachers.filter((teacher) => teacherDailyMap.get(teacher.id)?.here === 'present')
			: teachers.filter((teacher) => teacherDailyMap.get(teacher.id)?.here !== 'absent')
	);

	let searchParams: URLSearchParams = $state(data.searchParams);
	let slide = $state(data?.slide ?? 0);
	const clearSlideParams = () => {
		// searchParams = new URLSearchParams();
	};
	onMount(async () => {
		pb.collection('student_dailies').subscribe('*', (e: RecordSubscription<StudentDaily>) => {
			if (e.record.date !== todayISOString) return;
			const newStudentDailyMap = new Map(studentDailyMap);
			switch (e.action) {
				case 'create':
					newStudentDailyMap.set(e.record.student, e.record);
					if (e.record.here) updateSound(e.record.student, e.record.here);
					break;
				case 'update':
					const oldRecord = newStudentDailyMap.get(e.record.student);
					newStudentDailyMap.set(e.record.student, e.record);
					if (!e.record.here && oldRecord?.here) {
						updateSound(e.record.student, e.record.here);
					} else if (e.record.here && e.record.here !== oldRecord?.here) {
						updateSound(e.record.student, e.record.here);
					}
					break;
				case 'delete':
					newStudentDailyMap.delete(e.record.student);
					break;
			}
			studentDailyMap = newStudentDailyMap;
		});

		pb.collection('teacher_dailies').subscribe('*', (e: RecordSubscription<TeacherDaily>) => {
			if (e.record.date !== todayISOString) return;
			const newTeacherDailyMap = new Map(teacherDailyMap);
			switch (e.action) {
				case 'create':
					newTeacherDailyMap.set(e.record.teacher, e.record);
					if (e.record.here) updateSound(e.record.teacher, e.record.here);
					break;
				case 'update':
					const oldRecord = newTeacherDailyMap.get(e.record.teacher);
					newTeacherDailyMap.set(e.record.teacher, e.record);
					if (!e.record.here && oldRecord?.here) {
						updateSound(e.record.teacher, e.record.here);
					} else if (e.record.here && e.record.here !== oldRecord?.here) {
						updateSound(e.record.teacher, e.record.here);
					}
					break;
				case 'delete':
					newTeacherDailyMap.delete(e.record.teacher);
					break;
			}
			teacherDailyMap = newTeacherDailyMap;
		});

		onDestroy(() => {
			// sounds multiply if not removed (mainly in dev mode)
			pb.collection('student_dailies').unsubscribe('*');
			pb.collection('teacher_dailies').unsubscribe('*');
		});
	});

	const updateNavUrl = (page: number, searchParams: URLSearchParams) => {
		console.log('Updating nav URL:', page, searchParams);
		if (typeof window === 'undefined') return;

		requestAnimationFrame(() => {
			const url = new URL(window.location.href);
			url.pathname = `/present/${slide}/${page}`;

			url.search = '';
			for (const [key, value] of searchParams.entries()) {
				url.searchParams.set(key, value);
			}

			pushState(url, {}); // {} = custom page state if needed
		});
	};

	const slideLeft = () => {
		if (slide > 0) slide++;
	};
	const slideRight = () => {
		if (slide < 1) slide--;
	};
</script>

{#if slide === 0}
	<Attendance
		{todayISOString}
		{students}
		{teachers}
		{studentDailyMap}
		{teacherDailyMap}
		bind:searchParams
		{slideLeft}
		{slideRight}
		clearSearchParams={clearSlideParams}
		{updateNavUrl}
	/>
{/if}
