import type { PageLoad } from './$types';
// import { getAllStudents, getAllTeachers, pb } from '$lib/pb';
// import type { Student, StudentDaily, Teacher } from '$lib/pb/types';


export const load = (async ({  }) => {

	return {

	};
}) satisfies PageLoad;