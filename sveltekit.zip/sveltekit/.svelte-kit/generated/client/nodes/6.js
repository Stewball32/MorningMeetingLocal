import * as universal from "../../../../src/routes/teacher/attendance/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/teacher/attendance/+page.svelte";