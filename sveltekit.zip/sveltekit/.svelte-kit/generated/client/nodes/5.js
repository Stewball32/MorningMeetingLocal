import * as universal from "../../../../src/routes/present/[[slide]]/[[page]]/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/present/[[slide]]/[[page]]/+page.svelte";