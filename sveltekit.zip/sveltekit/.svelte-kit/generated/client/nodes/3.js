import * as universal from "../../../../src/routes/teacher/+layout.ts";
export { universal };
export { default as component } from "../../../../src/routes/teacher/+layout.svelte";