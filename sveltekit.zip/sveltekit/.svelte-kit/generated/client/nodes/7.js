import * as universal from "../../../../src/routes/teacher/weather/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/teacher/weather/+page.svelte";